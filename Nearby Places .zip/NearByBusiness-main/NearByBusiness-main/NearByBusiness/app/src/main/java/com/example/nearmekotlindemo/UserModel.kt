package com.example.nearmekotlindemo

data class UserModel(
    var email: String = "",
    var username: String = "",
    var image: String = ""
)