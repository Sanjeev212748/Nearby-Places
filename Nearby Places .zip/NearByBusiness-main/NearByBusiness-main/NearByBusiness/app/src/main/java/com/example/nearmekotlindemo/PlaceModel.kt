package com.example.nearmekotlindemo

class PlaceModel(
    var id: Int,
    var drawableId: Int,
    var name: String,
    var placeType: String
)